context("Clayton-Oakes")

test_that("Clayton-Oakes I", {  
  ## expect_equivalent(coef(e)[[1]][1:2,1],coef(lm(y~x,d)))
  ##  expect_equivalent(coef(e)[[2]][1:2,1],coef(lm(y~x,d)))
})


