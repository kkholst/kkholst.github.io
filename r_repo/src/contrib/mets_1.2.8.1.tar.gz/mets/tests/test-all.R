if (require(testthat)) {
    library("mets")
    library("lava")
    library("timereg")
    test_check("mets")
}
