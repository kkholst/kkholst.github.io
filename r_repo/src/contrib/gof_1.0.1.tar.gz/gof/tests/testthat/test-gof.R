context("gof")

testthat::test_that("Cumulative residuals test", {
    testthat::expect_true(TRUE)
})


